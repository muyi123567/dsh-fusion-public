/**
 * The single authorization gate for every agent-bus operation.
 *
 * One function, called from one place per tool. The reference implementation
 * this replaces had an exported `requireSameWorkspace` that no caller ever
 * invoked, with each handler hand-rolling its own check — three of its tools
 * ended up with no gate at all. Reachability is decided here or nowhere.
 *
 * No role field participates. Authority is derived from durable relationships,
 * mirroring the harness's own lineage check: reachability from shared
 * workspace membership, settlement authority from the recorded dispatcher.
 *
 * @module dsh-agent-bus/authorize
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { WorkspaceRegistry } from '@deepseek-ai/dsh-workspace';
import type { TaskRecord } from './types.ts';
/** Why an operation was refused. */
export type DenialReason = 'caller-not-live' | 'caller-has-no-workspace' | 'target-not-live' | 'target-outside-workspace' | 'target-is-subagent' | 'target-not-in-workspace' | 'target-archived' | 'self-delivery' | 'not-dispatcher' | 'task-not-found';
/** A refusal carrying the reason and a model-facing explanation. */
export interface Denial {
    readonly ok: false;
    readonly reason: DenialReason;
    readonly message: string;
}
/** A granted peer operation, carrying the resolved participants. */
export interface PeerGrant {
    readonly ok: true;
    /** The verified live caller. */
    readonly caller: Agent;
    /** The verified live recipient. */
    readonly target: Agent;
    /** Canonical workspace path both share. */
    readonly workspacePath: string;
}
/** Outcome of a peer authorization request. */
export type PeerDecision = PeerGrant | Denial;
/** Grant for a note recipient (v1.5): the workspace is all that is needed. */
export interface NoteGrant {
    readonly ok: true;
    readonly workspacePath: string;
}
export type NoteDecision = NoteGrant | Denial;
/**
 * Resolve the canonical workspace path a live agent belongs to.
 *
 * `SessionHeader` carries no workspace id, so the only route is the session's
 * `cwd` through the registry's `realpath`-based lookup. Membership in the
 * registry is a two-part condition — the id must be in the durable account
 * AND the session's canonical `cwd` must equal the workspace path — so the
 * returned path is authoritative for equality comparisons.
 *
 * @param registry - the workspace registry service.
 * @param agent - the agent whose workspace to resolve.
 * @returns the canonical workspace path, or `undefined` when the agent has no
 * `cwd` or its directory is not a registered workspace.
 */
export declare function resolveWorkspacePath(registry: WorkspaceRegistry, agent: Agent): Promise<string | undefined>;
/**
 * Authorize one peer operation between two sessions.
 *
 * Both parties must be exactly live: ambient presence is neither liveness
 * proof nor authorization, so each id is resolved against `ctx.agents` and
 * compared by identity. A caller without a resolvable workspace is refused
 * outright rather than defaulted into a fallback workspace.
 *
 * @param ctx - the plugin context, used to resolve live agents.
 * @param registry - the workspace registry service.
 * @param callerId - the session claiming to act.
 * @param targetId - the intended peer.
 * @returns a grant with both resolved agents, or a refusal.
 */
export declare function authorizePeer(ctx: Context, registry: WorkspaceRegistry, callerId: SessionId, targetId: SessionId): Promise<PeerDecision>;
/**
 * Authorize a verdict on a completed task.
 *
 * Settlement authority belongs to the session recorded as the task's
 * reviewer — the explicit `assignedReviewer`, or the initiator when none was
 * named. This keeps the reviewer role emergent from the durable relationship
 * rather than a stored role flag, and it forecloses self-approval: a worker
 * that is not also the reviewer can never settle its own task.
 *
 * @param task - the ledger row to settle, or `undefined` when the id is unknown.
 * @param callerId - the session claiming settlement authority.
 * @returns `undefined` when authorized, otherwise the refusal.
 */
export declare function authorizeSettlement(task: TaskRecord | undefined, callerId: SessionId): Denial | undefined;
/**
 * Authorize a send_note recipient (v1.5 durable notes).
 *
 * Looser than {@link authorizePeer}: the recipient may be OFFLINE — the
 * note is queued and delivered when the recipient is live again. The
 * recipient must still be a real session of the caller's workspace (the
 * same registry index the sidebar uses), so messages never go to strangers
 * or to other workspaces.
 *
 * @param ctx - the plugin context, used to resolve live agents.
 * @param registry - the workspace registry service.
 * @param callerId - the session claiming to act.
 * @param targetId - the intended recipient (may be offline).
 * @returns a grant with the resolved caller and workspace path, or a refusal.
 */
export declare function authorizeNoteRecipient(ctx: Context, registry: WorkspaceRegistry, callerId: SessionId, targetId: SessionId): Promise<NoteDecision>;
/**
 * Authorize a delivery target that may be DORMANT (v1.5 wake-on-delivery).
 *
 * Looser than {@link authorizePeer}: the target may be offline, as long as
 * it is a real session of the caller's workspace (the same registry index
 * the sidebar uses). The caller still must be live and inside a workspace;
 * the target's identity is the registry account, never a guess. The caller
 * then wakes the target (see wake.ts) and delivers; if waking fails, the
 * task stays queued or the note is queued offline.
 *
 * @param ctx - the plugin context, used to resolve live agents.
 * @param registry - the workspace registry service.
 * @param callerId - the session claiming to act.
 * @param targetId - the intended target (may be dormant).
 * @returns a grant with the caller, workspace path, and liveness of the
 *   target, or a refusal.
 */
export declare function authorizePeerOrDormant(ctx: Context, registry: WorkspaceRegistry, callerId: SessionId, targetId: SessionId): Promise<PeerDecision>;
